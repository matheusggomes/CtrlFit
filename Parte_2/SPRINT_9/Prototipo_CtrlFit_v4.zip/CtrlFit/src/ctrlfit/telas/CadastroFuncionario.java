package ctrlfit.telas;

import ctrlfit.entity.Funcionario;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class CadastroFuncionario extends javax.swing.JFrame {

    private GerenciamentoFuncionarios gerenciamentoFuncionarios;
    private boolean modoAlterar = false;//variavel do tipo boolean, se o usuario clicar em exibir ela é alterar para verdadeiro
    private int codigoAtual;
    Funcionario funcionario;
    
    public CadastroFuncionario(GerenciamentoFuncionarios teste) {
        initComponents();
        this.gerenciamentoFuncionarios = teste;
    }
    
    public void trazerDados(int codigo, String nome, String cargo, String cpf, java.util.Date dtNascimento, String telefone, String celular, String endereco, String bairro, String cep, char sexo, double salario, java.util.Date dtAdmisao, String email, String usuario, String senha) {
        this.modoAlterar = true;
        this.codigoAtual = codigo;

        txtNomeFunc.setText(nome);
        txtCargoFunc.setText(cargo);
        txtCpfFunc.setText(cpf);
        txtDtNascimentoFunc.setText(String.valueOf(dtNascimento));
        txtTelefoneFunc.setText(telefone);
        txtCelularFunc.setText(celular);
        txtEnderecoFunc.setText(endereco);
        txtBairroFunc.setText(bairro);
        txtCepFunc.setText(cep);
        
        int aux;
        if (sexo == 'M') {
            aux = 0;
        } else if (sexo == 'F') {
            aux = 1;
        } else {
            aux = 2;
        }
        jComboBoxSexoFunc.setSelectedIndex(aux);

        txtSalarioFunc.setText(String.valueOf(salario));
        txtDtAdmissaoFunc.setText(String.valueOf(dtAdmisao));
        txtEmailFunc.setText(email);
        txtUsuarioFunc.setText(usuario);
        txtSenhaFunc.setText(senha);
        
        //nao editar usuario e senha
        //txtUsuarioFunc.setEditable(false);
        //txtSenhaFunc.setEditable(false);
    }
    
    public void cadastrar() {
        try {
            //estabelecer a conexão com o banco de dados
            Connection conexao = ctrlfit.conexao.ConexaoDAO.conectarBD();

            String sql = "INSERT INTO funcionario (Nome_Func, Cargo_Func, Cpf_Func,"
                    + " DtNascimento_Func, Telefone_Func, Celular_Func,"
                    + " Endereco_Func, Bairro_Func, Cep_Func, Sexo_Func, Salario_Func,"
                    + " DtAdmissao_Func, Email_Func, Senha_Func, Usuario_Func, Codigo_Usuario)"
                    + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            // Preparar a instrução SQL de inserção
            PreparedStatement st = conexao.prepareStatement(sql);

            // Definir os valores dos parâmetros
            st.setString(1, funcionario.getNome());
            st.setString(2, funcionario.getCargo());
            st.setString(3, funcionario.getCpf());
            st.setDate(4, (Date) funcionario.getDtNascimento());
            st.setString(5, funcionario.getTelefone());
            st.setString(6, funcionario.getCelular());
            st.setString(7, funcionario.getEndereco());
            st.setString(8, funcionario.getBairro());
            st.setString(9, funcionario.getCep());
            st.setString(10, String.valueOf(funcionario.getSexo()));
            st.setDouble(11, funcionario.getSalario());
            st.setDate(12, (Date) funcionario.getDtAdmisao());
            st.setString(13, funcionario.getEmail());
            st.setString(14, funcionario.getSenha());
            st.setString(15, funcionario.getUsuario());
            st.setInt(16, 0);

            // Executar o INSERT
            st.executeUpdate();

            JOptionPane.showMessageDialog(this, "Cadastro realizado com sucesso!");
        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
    
    public void alterar() {
        try {
            //estabelecer a conexão com o banco de dados
            Connection conexao = ctrlfit.conexao.ConexaoDAO.conectarBD();

            String sql = "UPDATE funcionario SET Nome_Func = ?, Cargo_Func = ?, Cpf_Func = ?,"
                    + " DtNascimento_Func = ?, Telefone_Func = ?, Celular_Func = ?,"
                    + " Endereco_Func = ?, Bairro_Func = ?, Cep_Func = ?,"
                    + " Sexo_Func = ?, Salario_Func = ?, DtAdmissao_Func = ?, Email_Func = ?,"
                    + " Senha_Func = ?, Usuario_Func = ? WHERE Codigo_Func = ?";

            // Preparar a instrução SQL
            PreparedStatement st = conexao.prepareStatement(sql);

            // Definir os valores dos parâmetros
            st.setString(1, funcionario.getNome());
            st.setString(2, funcionario.getCargo());
            st.setString(3, funcionario.getCpf());
            st.setDate(4, (Date) funcionario.getDtNascimento());
            st.setString(5, funcionario.getTelefone());
            st.setString(6, funcionario.getCelular());
            st.setString(7, funcionario.getEndereco());
            st.setString(8, funcionario.getBairro());
            st.setString(9, funcionario.getCep());
            st.setString(10, String.valueOf(funcionario.getSexo()));
            st.setDouble(11, funcionario.getSalario());
            st.setDate(12, (Date) funcionario.getDtAdmisao());
            st.setString(13, funcionario.getEmail());
            st.setString(14, funcionario.getSenha());
            st.setString(15, funcionario.getUsuario());
            st.setInt(16, funcionario.getCodigo());

            // Executar o UPDATE
            st.executeUpdate();
            JOptionPane.showMessageDialog(null, "Alteração realizada com sucesso!");
        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        txtNomeFunc = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtEnderecoFunc = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtDtNascimentoFunc = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtBairroFunc = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtTelefoneFunc = new javax.swing.JTextField();
        txtCelularFunc = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtEmailFunc = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtCepFunc = new javax.swing.JTextField();
        btnConfirmar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        txtSenhaFunc = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        txtSalarioFunc = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txtDtAdmissaoFunc = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        txtCpfFunc = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        txtCargoFunc = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtUsuarioFunc = new javax.swing.JTextField();
        jComboBoxSexoFunc = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Cadastro de Funcionário");

        jLabel1.setText("Nome:");

        jLabel2.setText("Endereço:");

        jLabel4.setText("Data de Nascimento: ");

        txtDtNascimentoFunc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDtNascimentoFuncActionPerformed(evt);
            }
        });

        jLabel5.setText("Bairro");

        jLabel6.setText("Sexo: ");

        jLabel7.setText("Telefone:");

        jLabel8.setText("Celular:");

        jLabel9.setText("Email:");

        jLabel10.setText("CEP:");

        txtCepFunc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCepFuncActionPerformed(evt);
            }
        });

        btnConfirmar.setText("Confirmar");
        btnConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmarActionPerformed(evt);
            }
        });

        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        jLabel13.setText("Senha:");

        jLabel14.setText("Salário:");

        jLabel15.setText("Data de admissão:");

        jLabel16.setText("CPF:");

        jLabel17.setText("Cargo:");

        jLabel3.setText("Usuário:");

        jComboBoxSexoFunc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "M", "F", "C" }));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel16)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtDtNascimentoFunc, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jComboBoxSexoFunc, 0, 1, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtNomeFunc, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(txtCpfFunc, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel17)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtCargoFunc, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(txtSenhaFunc)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel14)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txtSalarioFunc, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(txtEmailFunc, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                                .addComponent(txtTelefoneFunc, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jLabel8)))
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtCelularFunc)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel3)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(txtUsuarioFunc))))))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel10))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(txtCepFunc, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                                        .addComponent(jLabel5)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtBairroFunc, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(txtEnderecoFunc)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel15)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtDtAdmissaoFunc, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addComponent(btnConfirmar)
                            .addGap(18, 18, 18)
                            .addComponent(btnCancelar))))
                .addContainerGap(12, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNomeFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(txtCpfFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17)
                    .addComponent(txtCargoFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel4)
                    .addComponent(txtDtNascimentoFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBoxSexoFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtEnderecoFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel10)
                        .addComponent(txtCepFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel5))
                    .addComponent(txtBairroFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(txtTelefoneFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCelularFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(txtEmailFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(txtUsuarioFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(txtSenhaFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14)
                    .addComponent(txtSalarioFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtDtAdmissaoFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnConfirmar)
                    .addComponent(btnCancelar))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtDtNascimentoFuncActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDtNascimentoFuncActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDtNascimentoFuncActionPerformed

    private void txtCepFuncActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCepFuncActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCepFuncActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmarActionPerformed
        // TODO add your handling code here:
        String nome = txtNomeFunc.getText();
        String cargo = txtCargoFunc.getText();
        String cpf = txtCpfFunc.getText();
        Date dtNascimento = Date.valueOf(txtDtNascimentoFunc.getText());
        String telefone = txtTelefoneFunc.getText();
        String celular = txtCelularFunc.getText();
        String endereco = txtEnderecoFunc.getText();
        String bairro = txtBairroFunc.getText();
        String cep = txtCepFunc.getText();
        char sexo = ' ';
        if (jComboBoxSexoFunc.getSelectedIndex() == 0) {
            sexo = 'M';
        } else if (jComboBoxSexoFunc.getSelectedIndex() == 1) {
            sexo = 'F';
        } else {
            sexo = 'C';
        }
        double salario = Double.valueOf(txtSalarioFunc.getText());
        Date dtAdmissao = Date.valueOf(txtDtAdmissaoFunc.getText());
        String email = txtEmailFunc.getText();
        String senha = txtSenhaFunc.getText();
        String usuario = txtUsuarioFunc.getText();
        
        funcionario = new Funcionario(codigoAtual, nome, cargo, cpf, dtNascimento, telefone, celular, endereco, bairro, cep, sexo, salario, dtAdmissao, email, usuario, senha);
        
        if (modoAlterar) {
            alterar();
        } else {
            cadastrar();
        }

        dispose();
        gerenciamentoFuncionarios.carregarDadosFuncionarios();
    }//GEN-LAST:event_btnConfirmarActionPerformed

 

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnConfirmar;
    private javax.swing.JComboBox<String> jComboBoxSexoFunc;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField txtBairroFunc;
    private javax.swing.JTextField txtCargoFunc;
    private javax.swing.JTextField txtCelularFunc;
    private javax.swing.JTextField txtCepFunc;
    private javax.swing.JTextField txtCpfFunc;
    private javax.swing.JTextField txtDtAdmissaoFunc;
    private javax.swing.JTextField txtDtNascimentoFunc;
    private javax.swing.JTextField txtEmailFunc;
    private javax.swing.JTextField txtEnderecoFunc;
    private javax.swing.JTextField txtNomeFunc;
    private javax.swing.JTextField txtSalarioFunc;
    private javax.swing.JTextField txtSenhaFunc;
    private javax.swing.JTextField txtTelefoneFunc;
    private javax.swing.JTextField txtUsuarioFunc;
    // End of variables declaration//GEN-END:variables
}
