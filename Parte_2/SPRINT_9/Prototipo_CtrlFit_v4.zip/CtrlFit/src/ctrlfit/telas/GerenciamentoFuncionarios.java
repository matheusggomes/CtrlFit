package ctrlfit.telas;

import ctrlfit.entity.Funcionario;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class GerenciamentoFuncionarios extends javax.swing.JFrame {

    private boolean pesquisarFuncionario = false;
    Funcionario funcionario;
    
    public GerenciamentoFuncionarios() {
        initComponents();
        jTableFuncionarios.setDefaultEditor(Object.class, null);//Deixa a jTable não editavel
        carregarDadosFuncionarios();
    }
    
    public void carregarDadosFuncionarios(){
        try {
            Connection conexao = ctrlfit.conexao.ConexaoDAO.conectarBD();
            
            String sql = "";
            PreparedStatement st;
            
            if (pesquisarFuncionario) {
                String nomeFuncionario = txtPesquisarFuncionario.getText();
                int opcao = jComboBoxPesquisarFuncionario.getSelectedIndex();
                
                if (opcao == 1) {
                    sql = "SELECT Codigo_Func, Nome_Func, Cargo_Func, Celular_Func, Email_Func, Senha_Func "
                            + "FROM funcionario WHERE Nome_Func LIKE ? AND Cargo_Func = 'Recepcionista'";
                } else if (opcao == 2) {
                    sql = "SELECT Codigo_Func, Nome_Func, Cargo_Func, Celular_Func, Email_Func, Senha_Func "
                            + "FROM funcionario WHERE Nome_Func LIKE ? AND Cargo_Func = 'Instrutor'";
                } else if (opcao == 3) {
                    sql = "SELECT Codigo_Func, Nome_Func, Cargo_Func, Celular_Func, Email_Func, Senha_Func "
                            + "FROM funcionario WHERE Nome_Func LIKE ? AND Cargo_Func = 'Gerente'";
                } else {
                    sql = "SELECT Codigo_Func, Nome_Func, Cargo_Func, Celular_Func, Email_Func, Senha_Func "
                            + "FROM funcionario WHERE Nome_Func LIKE ?";
                }
                
                st = conexao.prepareStatement(sql);
                st.setString(1, "%" + nomeFuncionario + "%");// Define o valor para o parâmetro
                
            } else {
                int opcao = jComboBoxPesquisarFuncionario.getSelectedIndex();
                
                if (opcao == 1) {
                    sql = "SELECT Codigo_Func, Nome_Func, Cargo_Func, Celular_Func, Email_Func, Senha_Func FROM funcionario WHERE Cargo_Func = 'Recepcionista'";
                } else if (opcao == 2) {
                    sql = "SELECT Codigo_Func, Nome_Func, Cargo_Func, Celular_Func, Email_Func, Senha_Func FROM funcionario WHERE Cargo_Func = 'Instrutor'";
                } else if (opcao == 3) {
                    sql = "SELECT Codigo_Func, Nome_Func, Cargo_Func, Celular_Func, Email_Func, Senha_Func FROM funcionario WHERE Cargo_Func = 'Gerente'";
                } else {
                    sql = "SELECT Codigo_Func, Nome_Func, Cargo_Func, Celular_Func, Email_Func, Senha_Func FROM funcionario";
                }
                
                st = conexao.prepareStatement(sql);
            }
            
            ResultSet rs = st.executeQuery();

            // Obter o modelo da tabela e limpar dados anteriores
            DefaultTableModel model = (DefaultTableModel) jTableFuncionarios.getModel();
            model.setRowCount(0);

            // Iterar pelos resultados e adicionar à tabela
            while (rs.next()) {
                int codigo = rs.getInt("Codigo_Func");
                String nome = rs.getString("Nome_Func");
                String cargo = rs.getString("Cargo_Func");
                String celular = rs.getString("Celular_Func");
                String email = rs.getString("Email_Func");
                String senha = rs.getString("Senha_Func");
                model.addRow(new Object[]{codigo, nome, cargo, celular, email, senha});
            }

        } catch (SQLException e) {
            System.out.println("Erro ao carregar dados: " + e.getMessage());
        }
    }
    
    public void excluir() {
        try {
            //estabelecer a conexão com o banco de dados
            Connection conexao = ctrlfit.conexao.ConexaoDAO.conectarBD();

            String sql = "DELETE FROM funcionario WHERE Codigo_Func = ?";
            PreparedStatement st = conexao.prepareStatement(sql);

            // Define o valor para o parâmetro (codigo_contato)
            st.setInt(1, funcionario.getCodigo());

            // Executar o DELETE
            st.executeUpdate();

            JOptionPane.showMessageDialog(this, "Exclusão realizada com sucesso!");
            carregarDadosFuncionarios();
        } catch (SQLException e) {
            System.out.println("Erro ao excluir funcionário: " + e.getMessage());
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTableFuncionarios = new javax.swing.JTable();
        btnCadastrarFuncionario = new javax.swing.JButton();
        btnExibirFuncionario = new javax.swing.JButton();
        btnExcluirFuncionario = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        txtPesquisarFuncionario = new javax.swing.JTextField();
        btnPesquisarFuncionario = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jComboBoxPesquisarFuncionario = new javax.swing.JComboBox<>();
        btnAtualizar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Gerenciamento de Funcionários");

        jTableFuncionarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null}
            },
            new String [] {
                "Código", "Nome ", "Cargo", "Celular", "E-mail", "Senha"
            }
        ));
        jScrollPane2.setViewportView(jTableFuncionarios);

        btnCadastrarFuncionario.setText("Cadastrar");
        btnCadastrarFuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarFuncionarioActionPerformed(evt);
            }
        });

        btnExibirFuncionario.setText("Exibir");
        btnExibirFuncionario.setToolTipText("Exibir ou Alterar dados");
        btnExibirFuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExibirFuncionarioActionPerformed(evt);
            }
        });

        btnExcluirFuncionario.setText("Excluir");
        btnExcluirFuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirFuncionarioActionPerformed(evt);
            }
        });

        jLabel1.setText("Pesquisar Funcionário:");

        btnPesquisarFuncionario.setText("Pesquisar");
        btnPesquisarFuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPesquisarFuncionarioActionPerformed(evt);
            }
        });

        jButton5.setText("Exportar");
        jButton5.setToolTipText("Exportar para PDF ou Excel");

        jLabel2.setText("Mostrar:");

        jComboBoxPesquisarFuncionario.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Todos os funcionários", "Recepcionista", "Instrutor", "Gerente" }));
        jComboBoxPesquisarFuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxPesquisarFuncionarioActionPerformed(evt);
            }
        });

        btnAtualizar.setText("Atualizar");
        btnAtualizar.setToolTipText("Resetar visualização");
        btnAtualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtualizarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 702, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtPesquisarFuncionario, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(btnPesquisarFuncionario)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnCadastrarFuncionario)
                        .addGap(18, 18, 18)
                        .addComponent(btnExibirFuncionario)
                        .addGap(18, 18, 18)
                        .addComponent(btnExcluirFuncionario))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton5))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jComboBoxPesquisarFuncionario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnAtualizar)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(7, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jComboBoxPesquisarFuncionario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAtualizar))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCadastrarFuncionario)
                    .addComponent(btnExibirFuncionario)
                    .addComponent(btnExcluirFuncionario)
                    .addComponent(jLabel1)
                    .addComponent(txtPesquisarFuncionario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPesquisarFuncionario))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton5)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnCadastrarFuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarFuncionarioActionPerformed
        // TODO add your handling code here:
        CadastroFuncionario cadastroFuncionario = new CadastroFuncionario(this);
        cadastroFuncionario.setVisible(true);
    }//GEN-LAST:event_btnCadastrarFuncionarioActionPerformed

    private void btnPesquisarFuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarFuncionarioActionPerformed
        // TODO add your handling code here:
        pesquisarFuncionario = true;
        carregarDadosFuncionarios();
        jComboBoxPesquisarFuncionario.setSelectedIndex(0);
    }//GEN-LAST:event_btnPesquisarFuncionarioActionPerformed

    private void btnExibirFuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExibirFuncionarioActionPerformed
        // TODO add your handling code here:
        //armazena o indice da linha na variavel linhaSelecionada, a primeira linha é 0, -1 para nenhuma linha selecionada
        int linhaSelecionada = jTableFuncionarios.getSelectedRow();

        if (linhaSelecionada != -1) {
            //obetr os valores da linha selecionada
            int codigo = (int) jTableFuncionarios.getValueAt(linhaSelecionada, 0);

            String nomeFunc = "";
            String cargoFunc = "";
            String cpfFunc = "";
            Date dtNascimentoFunc = null;
            String telefoneFunc = "";
            String celularFunc = "";
            String enderecoFunc = "";
            String bairroFunc = "";
            String cepFunc = "";
            char sexoFunc = ' ';
            double salarioFunc = 0;
            Date dtAdmissaoFunc = null;
            String emailFunc = "";
            String usuarioFunc= "";
            String senhaFunc = "";

            try {
                Connection conexao = ctrlfit.conexao.ConexaoDAO.conectarBD();
                String sql = "SELECT * FROM funcionario WHERE Codigo_Func = ?";
                PreparedStatement stmt = conexao.prepareStatement(sql);
                stmt.setInt(1, codigo);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    nomeFunc = rs.getString("Nome_Func");
                    cargoFunc = rs.getString("Cargo_Func");
                    cpfFunc = rs.getString("Cpf_Func");
                    dtNascimentoFunc = rs.getDate("DtNascimento_Func");
                    telefoneFunc = rs.getString("Telefone_Func");
                    celularFunc = rs.getString("Celular_Func");
                    enderecoFunc = rs.getString("Endereco_Func");
                    bairroFunc = rs.getString("Bairro_Func");
                    cepFunc = rs.getString("Cep_Func");
                    sexoFunc = rs.getString("Sexo_Func").charAt(0);
                    salarioFunc = rs.getDouble("Salario_Func");
                    dtAdmissaoFunc = rs.getDate("DtAdmissao_Func");
                    emailFunc = rs.getString("Email_Func");
                    usuarioFunc = rs.getString("Usuario_Func");
                    senhaFunc = rs.getString("Senha_Func");
                }

            } catch (SQLException e) {
                System.out.println("Erro: " + e.getMessage());
            }

            CadastroFuncionario cadastroFunc = new CadastroFuncionario(this);
            cadastroFunc.setVisible(true);

            //chama o metodo trazerDados da classse CadastroExercicio passando como parametro os valores da linha selecionada
            cadastroFunc.trazerDados(codigo, nomeFunc, cargoFunc, cpfFunc, dtNascimentoFunc, telefoneFunc, celularFunc, enderecoFunc, bairroFunc, cepFunc, sexoFunc, salarioFunc, dtAdmissaoFunc, emailFunc, usuarioFunc, senhaFunc);

        } else {
            JOptionPane.showMessageDialog(null, "Selecione uma linha para exibir!");
        }
    }//GEN-LAST:event_btnExibirFuncionarioActionPerformed

    private void btnExcluirFuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirFuncionarioActionPerformed
        // TODO add your handling code here:
        //armazena o indice da linha na variavel linhaSelecionada, a primeira linha é 0, -1 para nenhuma linha selecionada
        int linhaSelecionada = jTableFuncionarios.getSelectedRow();

        if (linhaSelecionada != -1) {
            // Obter o codigo da linha selecionada
            int codigo = (int) jTableFuncionarios.getValueAt(linhaSelecionada, 0);

            funcionario = new Funcionario();
            funcionario.setCodigo(codigo);
            Object[] opcoes = {"Sim", "Não"};
            int resposta = JOptionPane.showOptionDialog(
                    this,
                    "Você deseja realmente excluir esse funcionário?",
                    "Confirmação de Exclusão",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null, // Ícone padrão
                    opcoes, // Opções de botões personalizadas
                    opcoes[0] // Opção padrão selecionada
            );

            if (resposta == JOptionPane.YES_OPTION) {
                excluir();
            }

        } else {
            JOptionPane.showMessageDialog(this, "Selecione uma linha para excluir!");
        }
    }//GEN-LAST:event_btnExcluirFuncionarioActionPerformed

    private void jComboBoxPesquisarFuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxPesquisarFuncionarioActionPerformed
        // TODO add your handling code here:
        carregarDadosFuncionarios();
    }//GEN-LAST:event_jComboBoxPesquisarFuncionarioActionPerformed

    private void btnAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtualizarActionPerformed
        // TODO add your handling code here:                                             
        pesquisarFuncionario = false;
        carregarDadosFuncionarios();
        txtPesquisarFuncionario.setText("");
        jComboBoxPesquisarFuncionario.setSelectedIndex(0);
    }//GEN-LAST:event_btnAtualizarActionPerformed

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAtualizar;
    private javax.swing.JButton btnCadastrarFuncionario;
    private javax.swing.JButton btnExcluirFuncionario;
    private javax.swing.JButton btnExibirFuncionario;
    private javax.swing.JButton btnPesquisarFuncionario;
    private javax.swing.JButton jButton5;
    private javax.swing.JComboBox<String> jComboBoxPesquisarFuncionario;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTableFuncionarios;
    private javax.swing.JTextField txtPesquisarFuncionario;
    // End of variables declaration//GEN-END:variables
}
