package ctrlfit.telas;

import ctrlfit.entity.Aluno;
import java.sql.Connection;
//import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CadastroAluno extends javax.swing.JFrame {

    private GerenciamentoAlunos gerenciamentoAlunos;
    private boolean modoAlterar = false;//variavel do tipo boolean, se o usuario clicar em exibir ela é alterar para verdadeiro
    private int matriculaAtual;
    Aluno aluno;

    GerenciamentoPagamentos gerenciamentoPagamentos = new GerenciamentoPagamentos();

    public CadastroAluno(GerenciamentoAlunos teste) {
        initComponents();
        this.gerenciamentoAlunos = teste;
    }

    public void trazerDados(int matricula, String cpf, String nome, java.util.Date dtNascimento, char sexo, String endereco, String bairro, String cep, String telefone, String celular, String email) {
        this.modoAlterar = true;
        this.matriculaAtual = matricula;

        txtMatriculaAluno.setText(String.valueOf(matricula));
        txtCpfAluno.setText(cpf);
        txtNomeAluno.setText(nome);

        //---------------------------------------------------------------------
        //txtDtNascimentoAluno.setText(String.valueOf(dtNascimento));

        // Definindo o formato desejado
        SimpleDateFormat formato = new SimpleDateFormat();

        // Formatando a data e definindo o texto no JTextField
        txtDtNascimentoAluno.setText(formato.format(dtNascimento));
        //---------------------------------------------------------------------

        
        int aux;
        if (sexo == 'M') {
            aux = 0;
        } else if (sexo == 'F') {
            aux = 1;
        } else {
            aux = 2;
        }
        jComboBoxSexoAluno.setSelectedIndex(aux);

        txtEndereco.setText(endereco);
        txtBairro.setText(bairro);
        txtCep.setText(cep);
        txtTelefone.setText(telefone);
        txtCelular.setText(celular);
        txtEmail.setText(email);

    }

    public void cadastrar() {
        try {
            //estabelecer a conexão com o banco de dados
            Connection conexao = ctrlfit.conexao.ConexaoDAO.conectarBD();

            String sql = "INSERT INTO aluno (Cpf_Aluno, Nome_Aluno, DtNascimento_Aluno,"
                    + " Sexo_Aluno, Endereco_Aluno, Bairro_Aluno,"
                    + " Cep_Aluno, Telefone_Aluno, Celular_Aluno, Email_Aluno)"
                    + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            // Preparar a instrução SQL de inserção
            PreparedStatement st = conexao.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            // Definir os valores dos parâmetros
            st.setString(1, aluno.getCpf());
            st.setString(2, aluno.getNome());

            //------------------------------------------------------------------
            //aluno.getDtNascimento() retorna um java.util.Date
            java.util.Date dataUtil = aluno.getDtNascimento();

            if (dataUtil != null) {
                java.sql.Date dataSql = new java.sql.Date(dataUtil.getTime());
                st.setDate(3, dataSql);
            } else {
                st.setNull(3, java.sql.Types.DATE);
            }
            //------------------------------------------------------------------

            st.setString(4, String.valueOf(aluno.getSexo()));
            st.setString(5, aluno.getEndereco());
            st.setString(6, aluno.getBairro());
            st.setString(7, aluno.getCep());
            st.setString(8, aluno.getTelefone());
            st.setString(9, aluno.getCelular());
            st.setString(10, aluno.getEmail());

            // Executar o INSERT
            int linhaAfetada = st.executeUpdate();

            // Verificar se a inserção foi bem-sucedida
            if (linhaAfetada > 0) {
                ResultSet rs = st.getGeneratedKeys();
                while (rs.next()) {
                    int matricula = rs.getInt(1);
                    //System.out.println("Inserção bem-sucedida! ID gerado: " + id);
                    JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso! \nMatrícula Gerada: " + matricula);
                    txtMatriculaAluno.setText(String.valueOf(matricula));
                    aluno.setMatricula(matricula);
                }

                //realiza o cadastro de pagamento
                String sql2 = "INSERT INTO pagamento (Aluno_Matricula_Aluno, NomeAluno_Pagamento, Situacao_Aluno)"
                        + " VALUES (?, ?, ?)";

                // Preparar a instrução SQL de inserção
                PreparedStatement st2 = conexao.prepareStatement(sql2);

                // Definir os valores dos parâmetros
                st2.setInt(1, aluno.getMatricula());
                st2.setString(2, aluno.getNome());
                st2.setString(3, "Pendente");

                st2.executeUpdate();

            } else {
                System.out.println("Nenhuma linha foi afetada.");
            }

        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public void alterar() {
        try {
            //estabelecer a conexão com o banco de dados
            Connection conexao = ctrlfit.conexao.ConexaoDAO.conectarBD();

            String sql = "UPDATE aluno SET Cpf_Aluno = ?, Nome_Aluno = ?, DtNascimento_Aluno = ?,"
                    + " Sexo_Aluno = ?, Endereco_Aluno = ?, Bairro_Aluno = ?,"
                    + " Cep_Aluno = ?, Telefone_Aluno = ?, Celular_Aluno = ?,"
                    + " Email_Aluno = ? WHERE Matricula_Aluno = ?";

            // Preparar a instrução SQL
            PreparedStatement st = conexao.prepareStatement(sql);

            // Definir os valores dos parâmetros
            st.setString(1, aluno.getCpf());
            st.setString(2, aluno.getNome());

            //------------------------------------------------------------------
            //aluno.getDtNascimento() retorna um java.util.Date
            java.util.Date dataUtil = aluno.getDtNascimento();

            if (dataUtil != null) {
                java.sql.Date dataSql = new java.sql.Date(dataUtil.getTime());
                st.setDate(3, dataSql);
            } else {
                st.setNull(3, java.sql.Types.DATE);
            }
            //------------------------------------------------------------------

            st.setString(4, String.valueOf(aluno.getSexo()));
            st.setString(5, aluno.getEndereco());
            st.setString(6, aluno.getBairro());
            st.setString(7, aluno.getCep());
            st.setString(8, aluno.getTelefone());
            st.setString(9, aluno.getCelular());
            st.setString(10, aluno.getEmail());
            st.setInt(11, aluno.getMatricula());

            // Executar o UPDATE
            st.executeUpdate();
            JOptionPane.showMessageDialog(null, "Alteração realizada com sucesso!");
        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        txtNomeAluno = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtMatriculaAluno = new javax.swing.JTextField();
        txtEndereco = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtBairro = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        btnConfirmarAluno = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        txtCpfAluno = new javax.swing.JFormattedTextField();
        jLabel11 = new javax.swing.JLabel();
        jComboBoxSexoAluno = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();
        txtCep = new javax.swing.JFormattedTextField();
        txtTelefone = new javax.swing.JFormattedTextField();
        txtCelular = new javax.swing.JFormattedTextField();
        txtDtNascimentoAluno = new javax.swing.JFormattedTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Cadastro de Aluno");

        jLabel1.setText("Nome:");

        jLabel2.setText("Endereço:");

        jLabel3.setText("Matrícula:");

        txtMatriculaAluno.setEditable(false);

        jLabel5.setText("Bairro");

        jLabel6.setText("Sexo: ");

        jLabel7.setText("Telefone:");

        jLabel8.setText("Celular:");

        jLabel9.setText("Email:");

        jLabel10.setText("CEP:");

        btnConfirmarAluno.setText("Confirmar");
        btnConfirmarAluno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmarAlunoActionPerformed(evt);
            }
        });

        jButton3.setText("Cancelar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel12.setText("CPF:");

        try {
            txtCpfAluno.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###.###.###-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ctrlfit/icons/foto_aluno.png"))); // NOI18N
        jLabel11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jComboBoxSexoAluno.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "M", "F", "C" }));

        jLabel13.setText("Data de Nascimento:");

        try {
            txtCep.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("#####-###")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        try {
            txtTelefone.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("(##)####-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        try {
            txtCelular.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("(##)#####-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        try {
            txtDtNascimentoAluno.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel1))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtNomeAluno)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(txtMatriculaAluno, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel12)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtCpfAluno))))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel10))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(txtCep, javax.swing.GroupLayout.DEFAULT_SIZE, 83, Short.MAX_VALUE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel5)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtBairro, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(txtEndereco)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel9))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(txtTelefone)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel8)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtCelular, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(txtEmail)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addGap(18, 18, 18)
                                .addComponent(txtDtNascimentoAluno)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel6)
                                .addGap(8, 8, 8)
                                .addComponent(jComboBoxSexoAluno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnConfirmarAluno)
                        .addGap(18, 18, 18)
                        .addComponent(jButton3)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtMatriculaAluno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12)
                            .addComponent(txtCpfAluno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txtNomeAluno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(16, 16, 16)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(jComboBoxSexoAluno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13)
                            .addComponent(txtDtNascimentoAluno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(jLabel5)
                            .addComponent(txtCep, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtBairro)))
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(txtTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCelular, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnConfirmarAluno)
                    .addComponent(jButton3))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void btnConfirmarAlunoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmarAlunoActionPerformed

        String cpf = txtCpfAluno.getText();
        String nome = txtNomeAluno.getText();

        //----------------------------------------------------------------------
        Date dtNascimento = null;
        try {
            // Defina o formato da data que você deseja receber
            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");

            // Defina que o formato não deve permitir datas inválidas (como 32/13/2023)
            formato.setLenient(false);

            // Converta o texto para o objeto Date
            dtNascimento = formato.parse(txtDtNascimentoAluno.getText());

            // Se precisar de java.sql.Date para o banco de dados, converta assim:
            java.sql.Date sqlDate = new java.sql.Date(dtNascimento.getTime());

            // Agora você pode utilizar `sqlDate` para operações no banco de dados
            System.out.println("Data convertida: " + sqlDate);
        } catch (ParseException e) {
            System.out.println("Formato de data inválido!");
        }
        //----------------------------------------------------------------------

        char sexo = ' ';
        if (jComboBoxSexoAluno.getSelectedIndex() == 0) {
            sexo = 'M';
        } else if (jComboBoxSexoAluno.getSelectedIndex() == 1) {
            sexo = 'F';
        } else {
            sexo = 'C';
        }

        String endereco = txtEndereco.getText();
        String cep = txtCep.getText();
        String bairro = txtBairro.getText();
        String telefone = txtTelefone.getText();
        String celular = txtCelular.getText();
        String email = txtEmail.getText();

        aluno = new Aluno(matriculaAtual, cpf, nome, dtNascimento, sexo, endereco, bairro, cep, telefone, celular, email);

        if (modoAlterar) {
            alterar();
        } else {
            cadastrar();

            Object[] opcoes = {"Sim", "Não"};
            int resposta = JOptionPane.showOptionDialog(
                    this,
                    "Você deseja registrar o pagamento para esse aluno(a) agora?",
                    "Confirmação",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null, // Ícone padrão
                    opcoes, // Opções de botões personalizadas
                    opcoes[0] // Opção padrão selecionada
            );

            if (resposta == JOptionPane.YES_OPTION) {
                CadastroPagamento pagamento = new CadastroPagamento(gerenciamentoPagamentos, gerenciamentoAlunos, aluno.getMatricula(), aluno.getNome());
                pagamento.setVisible(true);

            }
        }

        dispose();
        gerenciamentoAlunos.carregarDadosAlunos();

    }//GEN-LAST:event_btnConfirmarAlunoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnConfirmarAluno;
    private javax.swing.JButton jButton3;
    private javax.swing.JComboBox<String> jComboBoxSexoAluno;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField txtBairro;
    private javax.swing.JFormattedTextField txtCelular;
    private javax.swing.JFormattedTextField txtCep;
    private javax.swing.JFormattedTextField txtCpfAluno;
    private javax.swing.JFormattedTextField txtDtNascimentoAluno;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtEndereco;
    private javax.swing.JTextField txtMatriculaAluno;
    private javax.swing.JTextField txtNomeAluno;
    private javax.swing.JFormattedTextField txtTelefone;
    // End of variables declaration//GEN-END:variables
}
