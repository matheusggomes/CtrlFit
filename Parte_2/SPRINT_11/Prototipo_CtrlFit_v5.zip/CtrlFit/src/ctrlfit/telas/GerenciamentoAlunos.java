package ctrlfit.telas;

import ctrlfit.excel.ExportarExcel;
import ctrlfit.conexao.ConexaoDAO;
import ctrlfit.entity.Aluno;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Date;
//import java.sql.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class GerenciamentoAlunos extends javax.swing.JFrame {

    private boolean pesquisarAluno = false;
    Aluno aluno;

    CadastroPagamento cadastroPag;

    public GerenciamentoAlunos() {
        initComponents();
        jTableAlunos.setDefaultEditor(Object.class, null);//Deixa a jTable não editavel
        carregarDadosAlunos();
    }

    public void carregarDadosAlunos() {
        atualizarSituacaoAlunos();
        try {
            Connection conexao = ctrlfit.conexao.ConexaoDAO.conectarBD();

            String sql = "";
            PreparedStatement st;

            if (pesquisarAluno) {
                String nomeAluno = txtPesquisarAluno.getText();
                int opcao = jComboBoxMostrarAlunos.getSelectedIndex();

                if (opcao == 1) {
                    sql = "SELECT a.Matricula_Aluno, a.Nome_Aluno, DATE_FORMAT(a.DtNascimento_Aluno, '%d/%m/%Y') AS DtNascimento_Aluno, a.Celular_Aluno, a.Email_Aluno, p.Situacao_Aluno "
                            + "FROM aluno a LEFT JOIN pagamento p ON a.Matricula_Aluno = p.Aluno_Matricula_Aluno WHERE Nome_Aluno LIKE ? AND Situacao_Aluno = 'Ativa'";
                } else if (opcao == 2) {
                    sql = "SELECT a.Matricula_Aluno, a.Nome_Aluno, DATE_FORMAT(a.DtNascimento_Aluno, '%d/%m/%Y') AS DtNascimento_Aluno, a.Celular_Aluno, a.Email_Aluno, p.Situacao_Aluno "
                            + "FROM aluno a LEFT JOIN pagamento p ON a.Matricula_Aluno = p.Aluno_Matricula_Aluno WHERE Nome_Aluno LIKE ? AND Situacao_Aluno = 'Pendente'";
                } else if (opcao == 3) {
                    sql = "SELECT a.Matricula_Aluno, a.Nome_Aluno, DATE_FORMAT(a.DtNascimento_Aluno, '%d/%m/%Y') AS DtNascimento_Aluno, a.Celular_Aluno, a.Email_Aluno, p.Situacao_Aluno "
                            + "FROM aluno a LEFT JOIN pagamento p ON a.Matricula_Aluno = p.Aluno_Matricula_Aluno WHERE Nome_Aluno LIKE ? AND Situacao_Aluno = 'Encerrada'";
                } else {
                    sql = "SELECT a.Matricula_Aluno, a.Nome_Aluno, DATE_FORMAT(a.DtNascimento_Aluno, '%d/%m/%Y') AS DtNascimento_Aluno, a.Celular_Aluno, a.Email_Aluno, p.Situacao_Aluno "
                            + "FROM aluno a LEFT JOIN pagamento p ON a.Matricula_Aluno = p.Aluno_Matricula_Aluno WHERE Nome_Aluno LIKE ?";
                }

                st = conexao.prepareStatement(sql);
                st.setString(1, "%" + nomeAluno + "%");
            } else {
                int opcao = jComboBoxMostrarAlunos.getSelectedIndex();

                if (opcao == 1) {
                    sql = "SELECT a.Matricula_Aluno, a.Nome_Aluno, DATE_FORMAT(a.DtNascimento_Aluno, '%d/%m/%Y') AS DtNascimento_Aluno, a.Celular_Aluno, a.Email_Aluno, p.Situacao_Aluno "
                            + "FROM aluno a LEFT JOIN pagamento p ON a.Matricula_Aluno = p.Aluno_Matricula_Aluno WHERE Situacao_Aluno = 'Ativa'";
                } else if (opcao == 2) {
                    sql = "SELECT a.Matricula_Aluno, a.Nome_Aluno, DATE_FORMAT(a.DtNascimento_Aluno, '%d/%m/%Y') AS DtNascimento_Aluno, a.Celular_Aluno, a.Email_Aluno, p.Situacao_Aluno "
                            + "FROM aluno a LEFT JOIN pagamento p ON a.Matricula_Aluno = p.Aluno_Matricula_Aluno WHERE Situacao_Aluno = 'Pendente'";
                } else if (opcao == 3) {
                    sql = "SELECT a.Matricula_Aluno, a.Nome_Aluno, DATE_FORMAT(a.DtNascimento_Aluno, '%d/%m/%Y') AS DtNascimento_Aluno, a.Celular_Aluno, a.Email_Aluno, p.Situacao_Aluno "
                            + "FROM aluno a LEFT JOIN pagamento p ON a.Matricula_Aluno = p.Aluno_Matricula_Aluno WHERE Situacao_Aluno = 'Encerrada'";
                } else {
                    sql = "SELECT a.Matricula_Aluno, a.Nome_Aluno, DATE_FORMAT(a.DtNascimento_Aluno, '%d/%m/%Y') AS DtNascimento_Aluno, a.Celular_Aluno, a.Email_Aluno, p.Situacao_Aluno "
                            + "FROM aluno a LEFT JOIN pagamento p ON a.Matricula_Aluno = p.Aluno_Matricula_Aluno";
                }

                st = conexao.prepareStatement(sql);
            }

            ResultSet rs = st.executeQuery();

            // Obter o modelo da tabela e limpar dados anteriores
            DefaultTableModel model = (DefaultTableModel) jTableAlunos.getModel();
            model.setRowCount(0);

            // Iterar pelos resultados e adicionar à tabela
            while (rs.next()) {
                int matricula = rs.getInt("Matricula_Aluno");
                String nome = rs.getString("Nome_Aluno");
                String plano = rs.getString("DtNascimento_Aluno");
                String dtInicio = rs.getString("Celular_Aluno");
                String dtFim = rs.getString("Email_Aluno");
                String situacao = rs.getString("Situacao_Aluno");
                model.addRow(new Object[]{matricula, nome, plano, dtInicio, dtFim, situacao});
            }

        } catch (SQLException e) {
            System.out.println("Erro ao carregar dados: " + e.getMessage());
        }
    }

    public void excluir() {
        try {
            //estabelecer a conexão com o banco de dados
            Connection conexao = ctrlfit.conexao.ConexaoDAO.conectarBD();

            //excluir primeiro o pagamento do aluno
            String sqlExcluirPagamento = "DELETE FROM pagamento WHERE Aluno_Matricula_Aluno = ?";
            PreparedStatement stExcluirPagamento = conexao.prepareStatement(sqlExcluirPagamento);

            // Define o valor para o parâmetro
            stExcluirPagamento.setInt(1, aluno.getMatricula());

            // Executar o DELETE
            stExcluirPagamento.executeUpdate();

            //--------------
            //excluir primeiro o pagamento do aluno
            String sqlExcluirTreino = "DELETE FROM treino WHERE Aluno_Matricula_Aluno = ?";
            PreparedStatement stExcluirTreino = conexao.prepareStatement(sqlExcluirTreino);

            // Define o valor para o parâmetro
            stExcluirTreino.setInt(1, aluno.getMatricula());

            // Executar o DELETE
            stExcluirTreino.executeUpdate();

            //excluir aluno----------------------------------------------
            String sqlExcluirAluno = "DELETE FROM aluno WHERE Matricula_Aluno = ?";
            PreparedStatement stExcluirAluno = conexao.prepareStatement(sqlExcluirAluno);

            // Define o valor para o parâmetro (codigo_contato)
            stExcluirAluno.setInt(1, aluno.getMatricula());

            // Executar o DELETE
            stExcluirAluno.executeUpdate();

            JOptionPane.showMessageDialog(this, "Exclusão realizada com sucesso!");
            carregarDadosAlunos();
        } catch (SQLException e) {
            System.out.println("Erro ao excluir aluno: " + e.getMessage());
        }
    }

    public void atualizarSituacaoAlunos() {
        try {
            Connection conexao = ctrlfit.conexao.ConexaoDAO.conectarBD();
            String sql = "SELECT Aluno_Matricula_Aluno, DtFim_Aluno FROM pagamento";
            PreparedStatement st = conexao.prepareStatement(sql);
            ResultSet rs = st.executeQuery();

            String updateSql = "UPDATE pagamento SET Situacao_Aluno = ? WHERE Aluno_Matricula_Aluno = ?";
            PreparedStatement updateSt = conexao.prepareStatement(updateSql);

            Date dataAtual = new Date();  // Data atual do sistema

            while (rs.next()) {
                int matricula = rs.getInt("Aluno_Matricula_Aluno");
                Date dtFimAluno = rs.getDate("DtFim_Aluno");

                String situacao = "";
                // Se DtFim_Aluno for nula, define a situação como "Pendente"
                if (dtFimAluno == null) {
                    situacao = "Pendente";
                } else {
                    // Verifica se DtFim_Aluno é maior ou igual à data atual
                    if (!dtFimAluno.before(dataAtual)) {
                        situacao = "Ativa";  // Se a data de fim for igual ou maior que a data atual, está ativa
                    } else {
                        // Se a data de fim for menor que a data atual, marca como "Pendente"
                        situacao = "Pendente";

                        // Verifica se a diferença entre a data atual e DtFim_Aluno é maior ou igual a 6 meses
                        Calendar calendario = Calendar.getInstance();
                        calendario.setTime(dtFimAluno);
                        calendario.add(Calendar.MONTH, 6);  // Adiciona 6 meses à DtFim_Aluno

                        Date seisMesesAposDtFim = calendario.getTime();

                        if (dataAtual.after(seisMesesAposDtFim) || dataAtual.equals(seisMesesAposDtFim)) {
                            situacao = "Encerrada";  // Se já passaram 6 meses ou mais, a situação é "Encerrada"
                        }
                    }
                }

                // Atualizar a situação do aluno
                updateSt.setString(1, situacao);
                updateSt.setInt(2, matricula);
                updateSt.executeUpdate();
            }

        } catch (SQLException e) {
            System.out.println("Erro ao atualizar situação dos alunos: " + e.getMessage());
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTableAlunos = new javax.swing.JTable();
        btnCadastrarAluno = new javax.swing.JButton();
        btnExibirAluno = new javax.swing.JButton();
        btnExcluirAluno = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        txtPesquisarAluno = new javax.swing.JTextField();
        btnPesquisarAluno = new javax.swing.JButton();
        btnExportar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jComboBoxMostrarAlunos = new javax.swing.JComboBox<>();
        btnAtualizar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Gerenciamento de Alunos");

        jTableAlunos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Matrícula", "Nome", "Data Nascimento", "Celular", "Email", "Situação Matrícula"
            }
        ));
        jScrollPane2.setViewportView(jTableAlunos);

        btnCadastrarAluno.setText("Cadastrar");
        btnCadastrarAluno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarAlunoActionPerformed(evt);
            }
        });

        btnExibirAluno.setText("Exibir");
        btnExibirAluno.setToolTipText("Exibir ou Alterar dados");
        btnExibirAluno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExibirAlunoActionPerformed(evt);
            }
        });

        btnExcluirAluno.setText("Excluir");
        btnExcluirAluno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirAlunoActionPerformed(evt);
            }
        });

        jLabel1.setText("Pesquisar Aluno:");

        btnPesquisarAluno.setText("Pesquisar");
        btnPesquisarAluno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPesquisarAlunoActionPerformed(evt);
            }
        });

        btnExportar.setText("Exportar");
        btnExportar.setToolTipText("Exportar para PDF ou Excel");
        btnExportar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExportarActionPerformed(evt);
            }
        });

        jLabel2.setText("Mostrar:");

        jComboBoxMostrarAlunos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Todos os alunos", "Alunos com matrícula ativa", "Alunos com matrícula pendente", "Alunos com matrícula encerrada" }));
        jComboBoxMostrarAlunos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxMostrarAlunosActionPerformed(evt);
            }
        });

        btnAtualizar.setText("Atualizar");
        btnAtualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtualizarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 789, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtPesquisarAluno, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnPesquisarAluno)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnCadastrarAluno)
                        .addGap(18, 18, 18)
                        .addComponent(btnExibirAluno)
                        .addGap(18, 18, 18)
                        .addComponent(btnExcluirAluno))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnExportar))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jComboBoxMostrarAlunos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnAtualizar)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(13, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jComboBoxMostrarAlunos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAtualizar))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCadastrarAluno)
                    .addComponent(btnExibirAluno)
                    .addComponent(btnExcluirAluno)
                    .addComponent(jLabel1)
                    .addComponent(txtPesquisarAluno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPesquisarAluno))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnExportar)
                .addGap(9, 9, 9))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnCadastrarAlunoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarAlunoActionPerformed
        // TODO add your handling code here:
        CadastroAluno cadastroAluno = new CadastroAluno(this);
        cadastroAluno.setVisible(true);
    }//GEN-LAST:event_btnCadastrarAlunoActionPerformed

    private void btnPesquisarAlunoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarAlunoActionPerformed
        pesquisarAluno = true;
        carregarDadosAlunos();
        jComboBoxMostrarAlunos.setSelectedIndex(0);
    }//GEN-LAST:event_btnPesquisarAlunoActionPerformed

    private void jComboBoxMostrarAlunosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxMostrarAlunosActionPerformed
        // TODO add your handling code here:
        carregarDadosAlunos();
    }//GEN-LAST:event_jComboBoxMostrarAlunosActionPerformed

    private void btnExibirAlunoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExibirAlunoActionPerformed
        // TODO add your handling code here:
        //armazena o indice da linha na variavel linhaSelecionada, a primeira linha é 0, -1 para nenhuma linha selecionada
        int linhaSelecionada = jTableAlunos.getSelectedRow();

        if (linhaSelecionada != -1) {
            //obetr os valores da linha selecionada
            int matricula = (int) jTableAlunos.getValueAt(linhaSelecionada, 0);

            String cpfAluno = "";
            String nomeAluno = "";
            Date dtNascimento = null;
            char sexoAluno = ' ';
            String endereco = "";
            String cep = "";
            String bairro = "";
            String telefone = "";
            String celular = "";
            String email = "";

            try {
                Connection conexao = ctrlfit.conexao.ConexaoDAO.conectarBD();
                String sql = "SELECT * FROM aluno WHERE Matricula_Aluno = ?";
                                
                PreparedStatement stmt = conexao.prepareStatement(sql);
                stmt.setInt(1, matricula);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    cpfAluno = rs.getString("Cpf_Aluno");
                    nomeAluno = rs.getString("Nome_Aluno");
                    dtNascimento = rs.getDate("DtNascimento_Aluno");
                    sexoAluno = rs.getString("Sexo_Aluno").charAt(0);
                    endereco = rs.getString("Endereco_Aluno");
                    bairro = rs.getString("Bairro_Aluno");
                    cep = rs.getString("Cep_Aluno");
                    telefone = rs.getString("Telefone_Aluno");
                    celular = rs.getString("Celular_Aluno");
                    email = rs.getString("Email_Aluno");
                }

            } catch (SQLException e) {
                System.out.println("Erro: " + e.getMessage());
            }

            CadastroAluno cadastroAluno = new CadastroAluno(this);
            cadastroAluno.setVisible(true);

            //chama o metodo trazerDados da classse CadastroExercicio passando como parametro os valores da linha selecionada
            cadastroAluno.trazerDados(matricula, cpfAluno, nomeAluno, dtNascimento, sexoAluno, endereco, bairro, cep, telefone, celular, email);

        } else {
            JOptionPane.showMessageDialog(null, "Selecione uma linha para exibir!");
        }
    }//GEN-LAST:event_btnExibirAlunoActionPerformed

    private void btnExcluirAlunoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirAlunoActionPerformed
        //armazena o indice da linha na variavel linhaSelecionada, a primeira linha é 0, -1 para nenhuma linha selecionada
        int linhaSelecionada = jTableAlunos.getSelectedRow();

        if (linhaSelecionada != -1) {
            // Obter o codigo da linha selecionada
            int matricula = (int) jTableAlunos.getValueAt(linhaSelecionada, 0);

            aluno = new Aluno();
            aluno.setMatricula(matricula);
            Object[] opcoes = {"Sim", "Não"};
            int resposta = JOptionPane.showOptionDialog(
                    this,
                    "Você tem certeza que deseja excluir esse aluno(a)?\n \nO pagamento e a ficha de treino do aluno(a) também serão excluídos.",
                    "Confirmação de Exclusão",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null, // Ícone padrão
                    opcoes, // Opções de botões personalizadas
                    opcoes[0] // Opção padrão selecionada
            );

            if (resposta == JOptionPane.YES_OPTION) {
                excluir();
            }

        } else {
            JOptionPane.showMessageDialog(this, "Selecione uma linha para excluir!");
        }
    }//GEN-LAST:event_btnExcluirAlunoActionPerformed

    private void btnAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtualizarActionPerformed
        // TODO add your handling code here:
        pesquisarAluno = false;
        carregarDadosAlunos();
        txtPesquisarAluno.setText("");
        jComboBoxMostrarAlunos.setSelectedIndex(0);
    }//GEN-LAST:event_btnAtualizarActionPerformed

    private void btnExportarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExportarActionPerformed
        ExportarExcel exportar = new ExportarExcel();
        exportar.exportar(jTableAlunos);
    }//GEN-LAST:event_btnExportarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAtualizar;
    private javax.swing.JButton btnCadastrarAluno;
    private javax.swing.JButton btnExcluirAluno;
    private javax.swing.JButton btnExibirAluno;
    private javax.swing.JButton btnExportar;
    private javax.swing.JButton btnPesquisarAluno;
    private javax.swing.JComboBox<String> jComboBoxMostrarAlunos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTableAlunos;
    private javax.swing.JTextField txtPesquisarAluno;
    // End of variables declaration//GEN-END:variables
}
